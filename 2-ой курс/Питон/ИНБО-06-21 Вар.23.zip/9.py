import re


def remove_none(x):
    res = []
    for row in x:
        temp = []
        for val in row:
            if val is None:
                continue
            temp.append(val)
        if len(temp):
            res.append(temp)

    return res


def remove_duplicates(x):
    res = []
    for row in x:
        if row in res:
            continue
        temp = []
        for item in row:
            if (item in temp):
                continue
            temp.append(item)

        res.append(temp)
    return res


def format(x):
    first_re = r'(\w+)\s*\w\.\w\.#(.+)'
    res = []
    for row in x:
        temp = []
        temp.append(row[0].replace('[at]', '@'))
        temp.append('1' if row[1] == 'Да' else '0')
        z = re.findall(first_re, row[2])
        print(z)
        temp.append(z[0][0])
        temp.append(f'{float(z[0][1]) * 100:.0f}%')
        res.append(temp)
    res.sort(key=lambda row: row[2])
    return res


def main(x):
    res = remove_none(x)
    res = remove_duplicates(res)
    res = format(res)
    return res
