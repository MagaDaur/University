import re


def main(x):
    r = r'variable\s*q\((\w+)\)\s*<=\s*@\'(\w+)\''
    z = re.findall(r, x)
    res = {}
    for group in z:
        res[group[0]] = group[1]
    return res
