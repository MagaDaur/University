from struct import *
import json

FMT = dict(
    char='c',
    int8='b',
    uint8='B',
    int16='h',
    uint16='H',
    int32='i',
    uint32='I',
    int64='q',
    uint64='Q',
    float='f',
    double='d'
)


def parse(buf, offs, ty, order='>'):
    pattern = FMT[ty]
    size = calcsize(pattern)
    value = unpack_from(order + pattern, buf, offs)[0]
    return value, offs + size


def parse_d(buf, offs):
    d1, offs = parse(buf, offs, 'uint32')
    d2, offs = parse(buf, offs, 'int8')
    d3, offs = parse(buf, offs, 'float')
    return dict(D1=d1, D2=d2, D3=d3), offs


def parse_c(buf, offs):
    c1_start, offs = parse(buf, offs, 'uint32')
    c1, _ = parse_d(buf, c1_start)
    c2, offs = parse(buf, offs, 'uint8')
    c3 = []
    for _ in range(5):
        c3_i, offs = parse(buf, offs, 'uint8')
        c3.append(c3_i)
    c4_size, offs = parse(buf, offs, 'uint32')
    c4_start, offs = parse(buf, offs, 'uint16')
    c4 = []
    for _ in range(c4_size):
        c4_i, c4_start = parse(buf, c4_start, 'int8')
        c4.append(c4_i)
    c5, offs = parse(buf, offs, 'float')
    c6, offs = parse(buf, offs, 'uint8')
    c7_size, offs = parse(buf, offs, 'uint32')
    c7_start, offs = parse(buf, offs, 'uint16')
    c7 = []
    for _ in range(c7_size):
        c7_i, c7_start = parse(buf, c7_start, 'int16')
        c7.append(c7_i)
    c8, offs = parse(buf, offs, 'uint64')
    return dict(C1=c1, C2=c2, C3=c3, C4=c4, C5=c5, C6=c6, C7=c7, C8=c8), offs


def parse_b(buf, offs):
    b1, offs = parse(buf, offs, 'int8')
    b2, offs = parse(buf, offs, 'uint32')
    b3, offs = parse(buf, offs, 'int8')
    b4, offs = parse(buf, offs, 'int32')
    b5_size, offs = parse(buf, offs, 'uint32')
    b5_start, offs = parse(buf, offs, 'uint32')
    b5 = []
    for _ in range(b5_size):
        b5_i, b5_start = parse(buf, b5_start, 'char')
        b5.append(b5_i.decode('utf-8'))
    b5 = ''.join(b5)

    return dict(B1=b1, B2=b2, B3=b3, B4=b4, B5=b5), offs


def parse_a(buf, offs):
    a1_start, offs = parse(buf, offs, 'uint16')
    a1, _ = parse_b(buf, a1_start)
    a2, offs = parse(buf, offs, 'int16')
    a3, offs = parse(buf, offs, 'uint16')
    a4, offs = parse(buf, offs, 'int8')
    a5 = []
    for _ in range(2):
        a5_i, offs = parse_c(buf, offs)
        a5.append(a5_i)
    a6, offs = parse(buf, offs, 'float')

    return dict(A1=a1, A2=a2, A3=a3, A4=a4, A5=a5, A6=a6), offs


def main(stream):
    return parse_a(stream, 4)[0]
