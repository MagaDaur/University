class MealyError(Exception):
    pass


class Automat():
    def __init__(self):
        self.state = 'A'

    def stand(self):
        if self.state == 'A':
            self.state = 'B'
            return 0
        if self.state == 'D':
            self.state = 'E'
            return 4
        if self.state == 'E':
            self.state = 'F'
            return 6
        raise MealyError('stand')

    def bolt(self):
        if self.state == 'A':
            self.state = 'E'
            return 1
        if self.state == 'B':
            self.state = 'C'
            return 2
        if self.state == 'C':
            self.state = 'D'
            return 3
        if self.state == 'D':
            self.state = 'F'
            return 5
        if self.state == 'E':
            self.state = 'C'
            return 7
        if self.state == 'F':
            self.state = 'C'
            return 8
        raise MealyError('bolt')


def main():
    return Automat()


def test():
    states = ['A', 'B', 'C', 'D', 'E', 'F']

    o = main()

    for state in states:
        try:
            o.state = state
            o.stand()

        except Exception as e:
            pass

    for state in states:
        try:
            o.state = state
            o.bolt()

        except Exception as e:
            pass
