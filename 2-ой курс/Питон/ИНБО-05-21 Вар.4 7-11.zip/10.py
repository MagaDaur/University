class MealyError(Exception):
    pass


class Automat():
    def __init__(self):
        self.state = 'A'

    def click(self):
        if self.state == 'A':
            self.state = 'B'
            return 0
        if self.state == 'B':
            self.state = 'C'
            return 2
        if self.state == 'C':
            self.state = 'D'
            return 4
        if self.state == 'D':
            self.state = 'E'
            return 6
        if self.state == 'E':
            self.state = 'F'
            return 7
        if self.state == 'G':
            self.state = 'E'
            return 10
        if self.state == 'H':
            self.state = 'E'
            return 11
        raise MealyError('click')
    
    def align(self):
        if self.state == 'A':
            self.state = 'G'
            return 1
        if self.state == 'B':
            self.state = 'E'
            return 3
        if self.state == 'C':
            self.state = 'E'
            return 5
        if self.state == 'F':
            self.state = 'G'
            return 8
        if self.state == 'G':
            self.state = 'H'
            return 9
        raise MealyError('align')


def main():
    return Automat()


def test():
    states = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

    o = main()

    for state in states:
        try:
            o.state = state
            o.click()

        except Exception as e:
            pass

    for state in states:
        try:
            o.state = state
            o.align()

        except Exception as e:
            pass
