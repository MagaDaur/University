from struct import *
import json

FMT = dict(
    char='c',
    int8='b',
    uint8='B',
    int16='h',
    uint16='H',
    int32='i',
    uint32='I',
    int64='q',
    uint64='Q',
    float='f',
    double='d'
)


def parse(buf, offs, ty, order='>'):
    pattern = FMT[ty]
    size = calcsize(pattern)
    value = unpack_from(order + pattern, buf, offs)[0]
    return value, offs + size


def parse_d(buf, offs):
    d1, offs = parse(buf, offs, 'int32')
    d2, offs = parse(buf, offs, 'uint32')
    d3, offs = parse(buf, offs, 'int8')
    return dict(D1=d1, D2=d2, D3=d3), offs


def parse_c(buf, offs):
    c1, offs = parse(buf, offs, 'uint64')
    c2_start, offs = parse(buf, offs, 'uint16')
    c2, _ = parse_d(buf, c2_start)
    return dict(C1=c1, C2=c2), offs


def parse_b(buf, offs):
    b1, offs = parse(buf, offs, 'uint16')
    b2_ptr_size, offs = parse(buf, offs, 'uint32')
    b2_ptr_start, offs = parse(buf, offs, 'uint16')
    b2 = []
    for _ in range(b2_ptr_size):
        b2_i_start, b2_ptr_start = parse(buf, b2_ptr_start, 'uint16')
        b2_i, _ = parse_c(buf, b2_i_start)
        b2.append(b2_i)
    b3 = []
    for _ in range(4):
        b3_i, offs = parse(buf, offs, 'char')
        b3.append(b3_i.decode('utf-8'))
    b3 = ''.join(b3)
    b4_size, offs = parse(buf, offs, 'uint32')
    b4_start, offs = parse(buf, offs, 'uint16')
    b4 = []
    for _ in range(b4_size):
        b4_i, b4_start = parse(buf, b4_start, 'int16')
        b4.append(b4_i)
    b5 = []
    for _ in range(5):
        b5_i, offs = parse(buf, offs, 'double')
        b5.append(b5_i)

    return dict(B1=b1, B2=b2, B3=b3, B4=b4, B5=b5), offs


def parse_a(buf, offs):
    a1, offs = parse(buf, offs, 'int8')
    a2, offs = parse(buf, offs, 'uint8')
    a3, offs = parse(buf, offs, 'float')
    a4, offs = parse(buf, offs, 'double')
    a5, offs = parse(buf, offs, 'uint32')
    a6, offs = parse(buf, offs, 'double')
    a7, offs = parse_b(buf, offs)

    return dict(A1=a1, A2=a2, A3=a3, A4=a4, A5=a5, A6=a6, A7=a7), offs


def main(stream):
    return parse_a(stream, 4)[0]
