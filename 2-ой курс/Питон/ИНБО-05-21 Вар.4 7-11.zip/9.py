import re
import math


def remove_none(x):
    res = []
    for row in x:
        temp = []
        for val in row:
            if val is None:
                continue
            temp.append(val)
        if len(temp):
            res.append(temp)

    return res


def remove_duplicates(x):
    res = []
    for row in x:
        temp = []
        for item in row:
            if item in temp:
                continue
            temp.append(item)
        if temp in res:
            continue
        res.append(temp)
    return res


def format(x):
    res = []
    for row in x:
        temp = []
        temp.append(row[0].replace('/', '.'))
        temp.append(row[1].replace('[at]', '@'))
        temp.append(row[2].replace(' ', ''))
        temp.append(row[3].split(',')[0])
        res.append(temp)
    return res


def transpose(x):
    res = [[], [], [], []]
    for row in x:
        res[0].append(row[0])
        res[1].append(row[1])
        res[2].append(row[2])
        res[3].append(row[3])

    return res


def main(x):
    res = remove_none(x)
    res = remove_duplicates(res)
    res = format(res)
    res = transpose(res)
    return res
