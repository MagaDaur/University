import re


def main(x):
    r = r'decl\s*\'(\w+)\'\s*<\s*\|\s*\[([^\]]+)'
    z = re.findall(r, x)
    res = {}
    for group in z:
        res[group[0]] = [int(i) for i in group[1].split(',')]
    return res
