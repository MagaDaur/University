from struct import *
import json

FMT = dict(
    char='c',
    int8='b',
    uint8='B',
    int16='h',
    uint16='H',
    int32='i',
    uint32='I',
    int64='q',
    uint64='Q',
    float='f',
    double='d'
)


def parse(buf, offs, ty, order='>'):
    pattern = FMT[ty]
    size = calcsize(pattern)
    value = unpack_from(order + pattern, buf, offs)[0]
    return value, offs + size


def parse_e(buf, offs):
    e1, offs = parse(buf, offs, 'int64')
    e2_size, offs = parse(buf, offs, 'uint32')
    e2_start, offs = parse(buf, offs, 'uint32')
    e2 = []
    for _ in range(e2_size):
        e2_i, e2_start = parse(buf, e2_start, 'double')
        e2.append(e2_i)
    e3, offs = parse(buf, offs, 'int8')
    return dict(E1=e1, E2=e2, E3=e3), offs


def parse_d(buf, offs):
    d1_size, offs = parse(buf, offs, 'uint16')
    d1_start, offs = parse(buf, offs, 'uint16')
    d1 = []
    for _ in range(d1_size):
        d1_i, d1_start = parse(buf, d1_start, 'int32')
        d1.append(d1_i)
    d2, offs = parse(buf, offs, 'double')
    d3, offs = parse(buf, offs, 'int8')
    d4 = []
    for _ in range(3):
        d4_i, offs = parse(buf, offs, 'uint8')
        d4.append(d4_i)
    d5, offs = parse(buf, offs, 'double')
    d6, offs = parse(buf, offs, 'int32')
    return dict(D1=d1, D2=d2, D3=d3, D4=d4, D5=d5, D6=d6), offs


def parse_c(buf, offs):
    c1, offs = parse(buf, offs, 'float')
    c2, offs = parse(buf, offs, 'int32')
    c3, offs = parse(buf, offs, 'uint8')
    return dict(C1=c1, C2=c2, C3=c3), offs


def parse_b(buf, offs):
    b1 = []
    for _ in range(3):
        b1_i, offs = parse_c(buf, offs)
        b1.append(b1_i)
    b2, offs = parse_d(buf, offs)
    b3, offs = parse(buf, offs, 'uint64')
    b4, offs = parse_e(buf, offs)
    b5, offs = parse(buf, offs, 'int64')
    b6, offs = parse(buf, offs, 'int16')
    b7, offs = parse(buf, offs, 'float')
    return dict(B1=b1, B2=b2, B3=b3, B4=b4, B5=b5, B6=b6, B7=b7), offs


def parse_a(buf, offs):
    a1 = []
    for _ in range(6):
        a1_i, offs = parse(buf, offs, 'char')
        a1.append(a1_i.decode('utf-8'))
    a1 = ''.join(a1)
    a2, offs = parse(buf, offs, 'double')
    a3, offs = parse_b(buf, offs)
    a4, offs = parse(buf, offs, 'int8')

    return dict(A1=a1, A2=a2, A3=a3, A4=a4), offs


def main(stream):
    return parse_a(stream, 4)[0]
