def main(x):
    W1 = x & 0b11111
    W2 = (x >> 5) & 0b111111111
    W3 = (x >> 14) & 0b11
    W5 = (x >> 18) & 0b111111111
    return W1, W2, W3, W5
