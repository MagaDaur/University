import re


def remove_none(x):
    res = []
    for row in x:
        temp = []
        for val in row:
            if val is None:
                continue
            temp.append(val)
        if len(temp):
            res.append(temp)

    return res


def remove_duplicates(x):
    res = []
    for row in x:
        if row in res:
            continue
        res.append(row)
    return res


def format(x):
    first_re = r'\+7\s*(\d+)\s*(\d+)-(\d+)-(\d+)&(\d+)\.(\d+)\.(\d+)'
    second_re = r'([^\[]+)\[at\](.+)'

    res = []
    for row in x:
        temp = []
        z_1 = re.findall(first_re, row[0])
        temp.append(f'{z_1[0][0]}-{z_1[0][1]}-{z_1[0][2]}{z_1[0][3]}')
        temp.append('Да' if row[1] == 'true' else 'Нет')
        z_2 = re.findall(second_re, row[2])
        temp.append(z_2[0][1])
        temp.append(f'{z_1[0][6]}-{z_1[0][5]}-{z_1[0][4]}')
        res.append(temp)
    return res


def main(x):
    res = remove_none(x)
    res = remove_duplicates(res)
    res = format(res)
    return res
