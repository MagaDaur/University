import re


def main(x):
    r = r'global\s*(\w+)\s*is\s*#\s*([^;]+);'
    z = re.findall(r, x)
    res = []
    for group in z:
        res.append((group[0], int(group[1])))
    return res
