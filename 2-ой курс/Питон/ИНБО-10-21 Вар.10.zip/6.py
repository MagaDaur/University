def zero(x, left, middle, right):
    if x[0] == 2012:
        return left
    elif x[0] == 2018:
        return middle
    return right


def two(x, left, right):
    if x[2] == 2017:
        return left
    return right


def three(x, left, right):
    if x[3] == 1958:
        return left
    return right


def main(x):
    if x[1] == 2011:
        return three(x, zero(x, 0, 1, 2), two(x, 3, 4))
    elif x[1] == 2002:
        return zero(x, three(x, 5, 6), two(x, 7, 8), two(x, 9, 10))

    return 11
