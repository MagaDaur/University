class MealyError(Exception):
    pass


class Automat():
    def __init__(self):
        self.state = 'A'

    def slip(self):
        if self.state == 'A':
            self.state = 'B'
            return 0
        if self.state == 'C':
            self.state = 'E'
            return 5
        if self.state == 'D':
            self.state = 'E'
            return 6
        if self.state == 'E':
            self.state = 'G'
            return 8
        raise MealyError('slip')

    def daub(self):
        if self.state == 'A':
            self.state = 'C'
            return 1
        if self.state == 'B':
            self.state = 'C'
            return 3
        if self.state == 'E':
            self.state = 'F'
            return 7
        raise MealyError('daub')

    def place(self):
        if self.state == 'A':
            self.state = 'D'
            return 2
        if self.state == 'C':
            self.state = 'D'
            return 4
        if self.state == 'F':
            self.state = 'G'
            return 9
        raise MealyError('place')


def main():
    return Automat()


def test():
    states = ['A', 'B', 'C', 'D', 'E', 'F', 'G']

    o = main()

    for state in states:
        try:
            o.state = state
            o.slip()

        except Exception as e:
            pass

    for state in states:
        try:
            o.state = state
            o.daub()

        except Exception as e:
            pass

    for state in states:
        try:
            o.state = state
            o.place()

        except Exception as e:
            pass
