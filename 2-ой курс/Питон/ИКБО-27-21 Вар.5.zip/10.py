class MealyError(Exception):
    pass


class Automat():
    def __init__(self):
        self.state = 'A'

    def lower(self):
        if self.state == 'A':
            self.state = 'B'
            return 0
        if self.state == 'B':
            self.state = 'C'
            return 1
        if self.state == 'C':
            return 3
        if self.state == 'D':
            self.state = 'E'
            return 4
        if self.state == 'E':
            self.state = 'G'
            return 6
        if self.state == 'G':
            self.state = 'H'
            return 8
        if self.state == 'H':
            self.state = 'A'
            return 10
        raise MealyError('lower')

    def hop(self):
        if self.state == 'C':
            self.state = 'D'
            return 2
        if self.state == 'E':
            self.state = 'F'
            return 5
        if self.state == 'F':
            self.state = 'G'
            return 7
        if self.state == 'G':
            self.state = 'B'
            return 9
        if self.state == 'H':
            self.state = 'B'
            return 11


def main():
    return Automat()


def test():
    states = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

    o = main()

    for state in states:
        try:
            o.state = state
            o.lower()

        except Exception as e:
            pass

    for state in states:
        try:
            o.state = state
            o.hop()

        except Exception as e:
            pass
