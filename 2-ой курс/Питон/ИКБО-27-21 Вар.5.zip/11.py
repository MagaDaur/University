from struct import *
import json

FMT = dict(
    char='c',
    int8='b',
    uint8='B',
    int16='h',
    uint16='H',
    int32='i',
    uint32='I',
    int64='q',
    uint64='Q',
    float='f',
    double='d'
)


def parse(buf, offs, ty, order='>'):
    pattern = FMT[ty]
    size = calcsize(pattern)
    value = unpack_from(order + pattern, buf, offs)[0]
    return value, offs + size


def parse_d(buf, offs):
    d1, offs = parse(buf, offs, 'float')
    d2, offs = parse(buf, offs, 'uint16')
    return dict(D1=d1, D2=d2), offs


def parse_c(buf, offs):
    c1, offs = parse(buf, offs, 'double')
    c2, offs = parse(buf, offs, 'uint64')
    c3, offs = parse(buf, offs, 'uint32')
    c4_size, offs = parse(buf, offs, 'uint32')
    c4_start, offs = parse(buf, offs, 'uint16')
    c4 = []
    for _ in range(c4_size):
        c4_i, c4_start = parse(buf, c4_start, 'int8')
        c4.append(c4_i)
    return dict(C1=c1, C2=c2, C3=c3, C4=c4), offs


def parse_b(buf, offs):
    b1_size, offs = parse(buf, offs, 'uint16')
    b1_start, offs = parse(buf, offs, 'uint16')
    b1 = []
    for _ in range(b1_size):
        b1_i, b1_start = parse(buf, b1_start, 'char')
        b1.append(b1_i.decode('utf-8'))
    b1 = ''.join(b1)
    b2, offs = parse(buf, offs, 'double')
    b3, offs = parse(buf, offs, 'int64')
    b4, offs = parse(buf, offs, 'uint8')
    b5 = []
    for _ in range(7):
        b5_i, offs = parse(buf, offs, 'char')
        b5.append(b5_i.decode('utf-8'))
    b5 = ''.join(b5)

    return dict(B1=b1, B2=b2, B3=b3, B4=b4, B5=b5), offs


def parse_a(buf, offs):
    a1_start, offs = parse(buf, offs, 'uint32')
    a1, _ = parse_b(buf, a1_start)
    a2, offs = parse(buf, offs, 'uint32')
    a3, offs = parse(buf, offs, 'int16')
    a4, offs = parse(buf, offs, 'int32')
    a5_size, offs = parse(buf, offs, 'uint16')
    a5_start, offs = parse(buf, offs, 'uint16')
    a5 = []
    for _ in range(a5_size):
        a5_i, a5_start = parse_c(buf, a5_start)
        a5.append(a5_i)
    a6, offs = parse_d(buf, offs)
    a7, offs = parse(buf, offs, 'uint32')
    a8, offs = parse(buf, offs, 'float')

    return dict(A1=a1, A2=a2, A3=a3, A4=a4, A5=a5, A6=a6, A7=a7, A8=a8), offs


def main(stream):
    return parse_a(stream, 3)[0]
