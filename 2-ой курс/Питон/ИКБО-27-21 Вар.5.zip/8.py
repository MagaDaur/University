import re


def main(x):
    r = r'glob\s*@\'(\w+)\'\s*to\s*\'(\w+)\''
    z = re.findall(r, x)
    res = {}
    for group in z:
        res[group[1]] = group[0]
    return res
