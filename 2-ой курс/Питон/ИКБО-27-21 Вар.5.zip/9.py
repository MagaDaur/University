import re


def remove_none(x):
    res = []
    for row in x:
        temp = []
        for val in row:
            if val is None:
                continue
            temp.append(val)
        if len(temp):
            res.append(temp)

    return res


def remove_duplicates(x):
    res = []
    for row in x:
        if row in res:
            continue
        temp = []
        for item in row:
            if (item in temp):
                continue
            temp.append(item)

        res.append(temp)
    return res


def format(x):
    first_re = r'(\w+)\|[^\]]+\](.*)'
    res = []
    for row in x:
        temp = []
        z = re.findall(first_re, row[0])
        temp.append(z[0][1])
        temp.append('Y' if z[0][0] == 'да' else 'N')
        date = row[1].split('-')
        date.reverse()
        temp.append('/'.join(date))
        val = float(row[2].replace('%', '')) / 100
        temp.append(f'{val:.3f}')
        res.append(temp)
    return res


def main(x):
    # res = remove_none(x)
    # res = remove_duplicates(res)
    res = format(x)
    return res
